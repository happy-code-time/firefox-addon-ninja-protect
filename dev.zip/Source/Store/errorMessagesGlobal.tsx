const errorMessagesGlobals = {
  messagesApp: {
    key: `432453443645654jlkjsldföäfsDFAJFOMFSDKMFOSDMAFODSMOGKewrg9034ut05uaopsjkovfgjsklöngvlöf`,
  },
};

export default errorMessagesGlobals;
