const removeAuthentication = () => {
  localStorage.removeItem('authentication');
}

export default removeAuthentication;