const version = '5.0.3';

const appName = 'Protector';

const appNameShort = 'Protector';

export {
    version,
    appName,
    appNameShort
};
