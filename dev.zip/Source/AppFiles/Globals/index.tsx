const version = '5.0.4';

const appName = 'Protector';

const appNameShort = 'Protector';

export {
    version,
    appName,
    appNameShort
};
