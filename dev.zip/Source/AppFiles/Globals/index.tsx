const version = '5.0.2';

const appName = 'Protector';

const appNameShort = 'Protector';

export {
    version,
    appName,
    appNameShort
};
