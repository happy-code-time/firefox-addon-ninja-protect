import * as React from 'react';

class ModuleHome extends React.Component
{
    render(){
        return (
            <div className="ContentBody Home"></div>
        );
    }
};

export default ModuleHome;