import * as React from 'react';

import getTranslations from '../../../Translations/index';

import customKey from '../../AppFiles/Functions/customKey';

import NoDataIframes from '../../AppFiles/Modules/NoDataIframes';

import LoadingAnimation from '../../AppFiles/Modules/LoadingAnimation';

interface WebsiteContainerProps {
    contentData?: string | any;
    loginRequired: boolean;
    redirectAfterLogin?: string;
}

class AppIcon extends React.Component {

    public translations: {
        [key: string]: any
    };

    public state: {
        [key: string]: any
    };

    constructor(props) {
        super(props);
        this.translations = getTranslations();
    }

    render(): JSX.Element {
        return (
            <div className="ContentBody ContentStaticHeight">
                <h1 className="ff-title text-center">
                    {
                        this.translations.ninjaIcon
                    }
                </h1>
                <a
                    className="dashboard-link"
                    target='_blank'
                    href='http://www.fasticon.com'
                >
                    http://www.fasticon.com
                </a>
            </div>
        );
    }
}

export default AppIcon;