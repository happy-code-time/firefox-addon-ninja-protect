const icons = {
    close: '✖'
};

export default icons