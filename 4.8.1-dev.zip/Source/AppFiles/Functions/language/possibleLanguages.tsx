const possibleLanguages = ['de', 'en', 'pl'];
export default possibleLanguages;