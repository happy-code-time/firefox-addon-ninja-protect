const version = '4.8.1';

const appName = 'Protector Ninja';

const appNameShort = 'Protector Ninja';

export {
    version,
    appName,
    appNameShort
};
