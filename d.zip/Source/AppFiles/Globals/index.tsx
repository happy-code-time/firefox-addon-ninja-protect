const version = '5.0.7';

const appName = 'Protector';

const appNameShort = 'Protector';

export {
    version,
    appName,
    appNameShort
};
